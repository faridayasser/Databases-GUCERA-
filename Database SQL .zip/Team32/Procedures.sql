USE GUCera_32

Go
create proc studentRegister
    @first_name varchar(20),
    @last_name varchar(20),
    @password varchar(20),
    @email varchar(50),
    @gender bit,
    @address varchar(10)
 as 


INSERT INTO users(first_name,last_name,Password,email,gender,Address)
values (@first_name,@last_name,@password,@email,@gender,@address) 
declare @ID  int
select @ID=max(id)from users
Insert into student(id)values(@ID)

exec studentRegister 'merna','michel','111','m@mail.com',1,'nasr city'

select * from users
SELECT * from instructor
select * from student

Go
create proc InstructorRegister
    @first_name varchar(20),
    @last_name varchar(20),
    @password varchar(20),
    @email varchar(50),
    @gender bit,
    @address varchar(10)
AS 

BEGIN
INSERT INTO users(first_name,last_name,Password,email,gender,Address)
values (@first_name,@last_name,@password,@email,@gender,@address) 
declare @ID  int
select @ID=max(id)from users

Insert into instructor(id)values(@ID)
END

GO
exec InstructorRegister 'rana','magdy','111','r@mail.com',1,'nasr city'


GO
create proc userLogin
@id INT,
@password varchar(20),
@success bit output,
@type int OUTPUT
 AS 
DECLARE @pass varchar (20)
SELECT @pass=[Password] FRom users
where @id=id
 IF
   @pass=@password 
BEGIN
   set @success = 1
IF EXISTS (SELECT id From student WHERE id=@id) 
   set @type = 2
IF EXISTS (SELECT id From admin WHERE id=@id) 
   set @type = 1
IF EXISTS (SELECT id From instructor WHERE id=@id) 
   set @type = 0
END
ELSE
    set @success = 0
    
 GO
 declare @success bit 
 DECLARE @type int
 exec userLogin 1,'111',@success output,@type output
 print  @success
 print  @type



select*from users

GO 
create proc addMobile
    @id int,
    @mobile_number varchar(20)
AS 
insert into UserMobileNumber(id,mobileNumber)values(@id,@mobile_number)


exec addMobile  1,'1111' 

select * from UserMobileNumber


GO
create proc AdminListInstr
 AS 
  SELECT u.First_name , u.Last_name 
  FROM users u inner join  instructor i on u.id=i.id

exec  AdminListInstr
   

GO 
create proc AdminViewInstructorProfile
   @instId  INt
   
AS
  SELECT u.First_name,u.Last_name,u.Gender,u.Email,u.Address,i.rating
  FROM instructor i , users u 
   where u.id=@instId and i.id=u.id
 

exec   AdminViewInstructorProfile 2

GO 
create proc  AdminViewAllCourses 
 AS
   SELECT name,credithours,price,content,accepted
   from course

 exec AdminViewAllCourses 

GO
create proc AdminViewNonAcceptedCourses
AS 
   SELECT name, credithours ,price,content FROM Course 
   WHERE accepted IS NULL
exec AdminViewNonAcceptedCourses

GO 
create proc AdminViewCourseDetails
@cid int
AS 
    SELECT name,credithours,price,content,accepted 
   from course
   where @cid=id

exec AdminViewCourseDetails 1

GO 
create proc AdminAcceptRejectCourse
@adminId int, @courseId int
AS  
UPDATE course 
SET accepted = 1, adminid = @adminId
WHERE id= @courseId

EXEC AdminAcceptRejectCourse 3,1


GO 
create proc AdminCreatePromocode
@code varchar(6),
@issuedate datetime,
@expirydate datetime,
@discount decimal(4,2),
@adminid int
AS 
INSERT INTO promocode (code,issuedate,expirydate,discountamount,adminid)
VALUES (@code,@issuedate,@expirydate,@discount,@adminid)

insert into users(first_name,last_name,Password,email,gender)
VALUEs ('salma','amr', 'pass', 's@gmail.com', 1)
SELECT * from Admin
INSERT into admin(id)
VALUES(3)
EXEC AdminCreatePromocode 'G101', '1/1/2019', '1/1/2020', 10 ,3


GO 
create proc AdminListAllStudents
AS
 SELECT u.first_name,u.Last_name
 FROM users u inner join student s on u.id=s.id

exec AdminListAllStudents

GO
create proc AdminViewStudentProfile
@sid int
AS
    SELECT u.First_name,u.Last_name,u.Gender,u.Email,u.Address,i.gpa
  FROM student i , users u 
   where u.id=@sid and i.id=u.id


 exec   AdminViewStudentProfile 1

go
 CREATE PROC AdminIssuePromocodeToStudent
 @sid int, 
 @pid varchar(6)
 AS

 INSERT into StudentHasPromcode(sid,code)
 VALUES(@sid,@pid)

EXEC AdminIssuePromocodeToStudent 1, 'G101'
select * from StudentHasPromcode

go
CREATE PROC InstAddCourse
    @creditHours Int,
    @name varchar(10),
    @price DECIMAL(6,2),
    @instructorId int
AS
Insert Into course(credithours,name, price, instructorid)
VALUES (@creditHours, @name, @price, @instructorId)
DECLARE @var INT
SELECT @var = id FROM course WHERE name = @name
INSERT INTO instructorteachcourse(instid,cid)
VALUES (@instructorId, @var )

EXEC InstAddCourse 2, db, 100, 2
select * FROM course
sELECT * from instructorteachcourse

GO 
CREATE PROC UpdateCourseContent
    @instructorid int,
    @courseId int,
    @content VARCHAR(100)

AS
Update course
SET content  = @content
WHERE id = @courseId AND instructorid = @instructorid

EXEC UpdateCourseContent 2, 1, 'intranet.guc.edu.eg/db1'
select * from course

GO 
CREATE PROC UpdateCourseDescription
    @instructorid int,
    @courseId int,
    @description VARCHAR(20)

AS
Update course
SET course_description  = @description
WHERE id = @courseId AND instructorid = @instructorid

EXEC UpdateCourseDescription 2,1,'Databases1'

go 
create PROC AddAnotherInstructorToCourse
    @instructorId int,
    @courseId int,
    @adderIns INT
AS
 IF exists (select instid, cid from instructorteachcourse where instid =@adderIns AND cid=@courseId)
Insert into instructorteachcourse(instid, cid)
Values (@instructorId, @courseId)
else PRINT 'The instructor adding does not teach this course'

EXEC InstructorRegister 's' ,'a','p','mail',1,'city'
select * from Instructor
EXEC AddAnotherInstructorToCourse 4, 1, 2

GO
CREATE PROC InstructorViewAcceptedCoursesByAdmin
@instructorid int
AS
SELECT id, name, credithours
FROM course 
WHERE instructorid = @instructorid AND accepted = 1

EXEC InstructorViewAcceptedCoursesByAdmin  2

GO
CREATE PROC DefineCoursePrerequisites
@cid int,
@prerequisiteid INT
AS
Insert into courseprerequisitecourse(cid, prerequisiteid)
VALUES (@cid, @prerequisiteid)

EXEC InstAddCourse 2, 'discrete', 100, 2
select * from course
EXEC DefineCoursePrerequisites  2, 1
select * from courseprerequisitecourse

GO 
CREATE PROC DefineAssignmentOfCourseOfCertianType
@instructorid int,
@cid int,
@number int,
@type VARCHAR(10),
@fullgrade int,
@weight decimal(4,1),
@deadline DATETIME,
@content VARCHAR(200)

AS
IF (exists (select instid, cid from instructorteachcourse where instid =@instructorid AND cid=@cid) AND exists (select * from course where id =@cid and accepted=1))
INSERT INTO assignment( cid, number,type ,fullgrade,weight, deadline,content)
VALUES (@cid,@number,@type,@fullgrade,@weight,@deadline,@content)
ELSE
PRINT 'This instructor does not teach this course or course is not accepted yet'

EXEC DefineAssignmentOfCourseOfCertianType 2, 1, 1, 'quiz', 10, 100, '12/12/2020', 'question1'
select * from assignment


GO
CREATE PROC updateInstructorRate
@InstrId INT

AS 
DECLARE @rates DECIMAL(2,1)
SELECT @rates = avg(rate) FROM studentrateinstructor
WHERE instid = @InstrId

UPDATE instructor
SET rating = @rates
WHERE id = @InstrId

EXEC updateInstructorRate 2


GO
CREATE PROC ViewInstructorProfile
@instId INT

AS
SELECT u.*, i.rating, m.mobileNumber
FROM users u 
INNER JOIN instructor i 
on i.id = u.Id
left OUTER JOIN UserMobileNumber m 
on m.id = i.id 
WHERE i.id = @instId

EXEC ViewInstructorProfile 2

GO 
CREATE PROC InstructorViewAssignmentsStudents
@instId int,
@cid INT
AS
if not exists(select instid, cid from instructorteachcourse where instid = @instId AND cid=@cid)
PRINT 'Instructor does not teach this course'
else
BEGIN
SELECT sid, cid ,assignmentnumber,assignmenttype 
from StudentTakeAssignment 
WHERE cid = @cid
END

EXEC InstructorViewAssignmentsStudents 2,1
select * from StudentTakeAssignment

Go 
create PROC InstructorgradeAssignmentOfAStudent
@instId int,
@sid int,
@cid int,
@assignmentnumber int,
@assignmentType VARCHAR(10),
@grade DECIMAL(5,2)

AS
if not exists(select instid, cid from instructorteachcourse where instid = @instId AND cid=@cid)
PRINT 'Instructor does not teach this course'
else
BEGIN
UPDATE StudentTakeAssignment
SET grade = @grade
WHERE sid = @sid AND cid = @cid AND assignmentnumber = @assignmentnumber AND assignmenttype = @assignmentType
END

select * from instructorteachcourse
EXEC InstructorgradeAssignmentOfAStudent 2, 1,1, 1, 'quiz', 10
select * from StudentTakeAssignment

GO
CREATE PROC ViewFeedbacksAddedByStudentsOnMyCourse
@instrId int, 
@cid int

AS
IF (exists(select instid, cid from InstructorTeachCourse where cid= @cid AND instid = @instrId) AND EXISTS (SELECT * FROM course where id=@cid and accepted=1))
SELECT * FROM 
feedback f
WHERE cid = @cid
ELSE
PRINT 'Instructor does not teach this course or this course is not accepted yet'


EXEC ViewFeedbacksAddedByStudentsOnMyCourse 2,1

GO
CREATE PROC calculateFinalGrade
@cid int , @sid int , @insId int

AS
if not exists(select instid, cid from instructorteachcourse where instid = @insId AND cid=@cid)
PRINT 'Instructor does not teach this course'
else
BEGIN
DECLARE @finalgrade DECIMAL(4,1)
SELECT @finalgrade= SUM(a.weight*(s.grade/a.fullgrade))
FROM StudentTakeAssignment s
INNER JOIN assignment a 
on s.cid = a.cid AND s.assignmentnumber =a.number AND s.assignmenttype = a.type
where sid =@sid and s.cid =@cid
UPDATE studenttakecourse
SET grade = @finalgrade
END


select * FROM assignment
EXEC calculateFinalGrade 1,1,2
select * from studenttakecourse

GO
CREATE PROC InstructorIssueCertificateToStudent
@cid int , @sid int , @insId int, @issueDate datetime
AS
IF not exists(select instid, cid from instructorteachcourse WHERE instid = @insId AND cid=@cid)
print 'Instructor does not teach this course'
ELSE 
BEGIN
DECLARE @grade DECIMAL(4,1)
SELECT @grade= grade from studenttakecourse WHERE sid =@sid AND cid = @cid
IF @grade >= 50
INSERT INTO studentcertifycourse (sid, cid, issuedate)
VALUES (@sid, @cid, @issueDate) 
ELSE print 'student has not passed this course'
END

EXEC InstructorIssueCertificateToStudent 1, 1, 2, '10/29/2020'
select * from studentcertifycourse

GO
CREATE PROC viewMyProfile
@id INT
AS
SELECT s.*, u.* FROM
users u 
INNER JOIN student s
on u.Id = s.id
WHERE s.id = @id


EXEC viewMyProfile 1

GO 
CREATE PROC editMyProfile
@id int, @firstName varchar(10), @lastName varchar(10), @password varchar(10), @gender binary, @email varchar(10), @address varchar(10)
AS
if @firstName is not NULL 
UPDATE users
SET First_name = @firstName
WHERE id = @id
if @lastName is not NULL 
UPDATE users
SET Last_name = @lastName
WHERE id = @id
if @password is not NULL 
UPDATE users
SET password = @password
WHERE id = @id
if @gender is not NULL 
UPDATE users
SET Gender = @gender, Email = @email, Address = @address
WHERE id = @id
if @email is not NULL 
UPDATE users
SET Email = @email, Address = @address
WHERE id = @id
if @address is not NULL 
UPDATE users
SET Address = @address
WHERE id = @id

EXEC editMyProfile 1,null,null,null,null,null, 'york'
select * FROM users WHERE id =1

GO
CREATE PROC availableCourses
AS
SELECT name
From course
WHERE accepted = 1

EXEC availableCourses

GO
create PROC courseInformation
@id INT
AS

SELECT c.credithours, c.name,c.course_description, u.First_name, u.Last_name
FROM course c 
INNER JOIN users u 
on c.instructorid = u.Id
WHERE c.id = @id AND c.accepted=1

EXEC courseInformation 1

GO
CREATE PROC enrollInCourse
@sid INT, @cid INT, @instr int
AS
if (exists(select * from course where id = @cid AND accepted=1 )and exists(select instid from instructorteachcourse where cid = @cid and instid=@instr))
INSERT INTO studenttakecourse (sid,cid,instid)
VALUES(@sid,@cid,@instr)
ELSE 
PRINT'course either does not exist or has not been accepted yet or instructor chosen does not teach this course'

EXEC enrollInCourse 1,1,2
select * from studenttakecourse

GO 
CREATE PROC addCreditCard
@sid int, @number varchar(15), @cardHolderName varchar(16), @expiryDate datetime, @cvv varchar(3)
AS
INSERT Into creditcard(Number,cardHolderrName,expiry_date,cvv)
VALUES (@number,@cardHolderName,@expiryDate,@cvv)
INSERT INTO StudentAddCreditCard(sid,creditcardnumber)
VALUES(@sid,@number)

EXEC addCreditCard  1, '123334111111111', 'Merna', '2/10/2019', '123'
select * from creditcard
SELECT * from StudentAddCreditCard

GO
CREATE PROC viewPromocode
@sid int
AS
SELECT p.* from StudentHasPromcode s
INNER JOIN promocode p
ON p.code = s.code
WHERE s.sid = @sid

EXEC viewPromocode 1

GO
CREATE PROC payCourse
@cid INT, @sid INT
AS
UPDATE studenttakecourse
SET payedfor = 1
WHERE sid =@sid AND cid = @cid

EXEC payCourse 1,1
select * from studenttakecourse

GO
CREATE PROC enrollInCourseViewContent
@id int, @cid INT
AS
if (exists(select id from course where id=@cid AND accepted=1) and exists(select sid from studenttakecourse where cid=@cid and sid=@id))
SELECT id, creditHours, name, course_description, price, content FROM course
WHERE id = @cid
ELSE
PRINT 'student is not enrolled in course or course is not yet accepted'

EXEC enrollInCourseViewContent 1,1

GO 
CREATE PROC viewAssign
@courseId int, @sid VARCHAR(10)
AS
if exists(select sid from studenttakecourse where sid=@sid and cid = @courseId)
SELECT * FROM assignment
WHERE cid = @courseId
ELSE
print 'student does not take this course'


EXEC viewAssign 1,1

GO
CREATE PROC submitAssign
@assignType VARCHAR(10), @assignnumber int, @sid INT, @cid INT
AS
if (exists(select sid from studenttakecourse where sid=@sid and cid = @cid) AND exists(select number from assignment where number=@assignnumber and type = @assignType and cid =@cid))
INSERT INTO StudentTakeAssignment(sid,cid,assignmentnumber,assignmenttype)
VALUES(@sid,@cid,@assignnumber,@assignType)
ELSE
PRINT 'student does not take this course or assignment does not exist'

EXEC submitAssign  'quiz', 1, 1, 1
select * from StudentTakeAssignment

GO
CREATE PROC viewAssignGrades
@assignnumber int, @assignType VARCHAR(10), @cid INT, @sid INT, @assignGrade INT OUTPUT
AS
DECLARE @g INT
SELECT @g = grade FROM StudentTakeAssignment WHERE assignmentnumber = @assignnumber AND assignmenttype= @assignType AND cid =@cid AND sid =@sid
SET @assignGrade = @g
PRINT @assignGrade


DECLARE @out INT 
EXEC viewAssignGrades 1, 'quiz', 1, 1, @out OUTPUT
PRINT @out
select * from StudentTakeAssignment

GO 
CREATE PROC viewFinalGrade
@cid INT, @sid INT, @finalgrade decimal(10,2) OUTPUT

AS
IF exists(select cid, sid from studenttakecourse where sid = @sid AND cid = @cid) 
BEGIN
declare @grade decimal(10,2)
SELECT @grade =grade from studenttakecourse WHERE sid =@sid and cid=@cid
set @finalgrade = @grade
PRINT @finalgrade
END
ELSE 
PRINT 'student does not take this course'

declare @f DECIMAL(10,2)
EXEC viewFinalGrade 1,1 ,@f output

GO
CREATE PROC addFeedback
@comment VARCHAR(100), @cid INT, @sid INT

AS
if exists(select cid, sid from studenttakecourse where sid = @sid AND cid = @cid)
INSERT INTO feedback(cid, comment,numberOflikes, sid)
VALUES(@cid,@comment,0, @sid)

EXEC addFeedback 'Good', 1, 1
select * from feedback

GO
CREATE PROC rateInstructor
@rate DECIMAL (2,1), @sid INT, @insid INT

AS
IF exists(select sid, instid from studenttakecourse WHERE sid = @sid AND instid = @insid)
INSERT into studentrateinstructor(sid,instid,rate)
VALUES(@sid, @insid, @rate)
else
PRINT 'Not a student of this course'
EXEC rateInstructor 2,1,2
select * from studentrateinstructor


GO
CREATE PROC viewCertificate
@cid INT, @sid INT

AS
IF exists(select * from studentcertifycourse where cid =@cid and sid=@sid)
SELECT * FROM studentcertifycourse
WHERE sid=@sid
ELSE 
PRINT 'student has no certificate in this course'


EXEC viewCertificate 1,1

