CREATE DATABASE GUCera_32

GO 

USE GUCera_32
Create table Users(
Id INT identity,
First_name varchar(20) not null,
Last_name varchar (20) not NULL,
Password varchar(20) not null,
Gender bit not null,
Email varchar(50) UNIQUE not null,
Address varchar (10),
Primary key(id));

create table Instructor(
id int,
rating decimal(2,1) DEFAULT 0.0,
PRIMARY KEY(id),
FOREIGN KEY (id) REFERENCES users on DELETE CASCADE on UPDATE CASCADE
);
create table UserMobileNumber(
    id int ,
    mobileNumber VARCHAR(20),
    Primary key(id,mobileNumber),
Foreign key (id) references users
On delete cascade On update cascade);

create table Student(
    id int,
    gpa decimal(5,2) default 0.00,
    PRIMARY KEY(id),
    FOREIGN KEY (id)REFERENCES users on delete cascade on update cascade,
);


create table Admin(
    id int,
    PRIMARY KEY(id),
    FOREIGN KEY (id)REFERENCES users
    on delete cascade on update cascade,
);
create table Course(
    id int IDENTITY,
    credithours int  not null,
    name varchar(10) not null,
    course_description varchar(200),
    price decimal(6,2) not null,
    content varchar(100),
    adminid int,
    instructorid int not null,
    accepted BIT default NULL,
    PRIMARY KEY(id),
    FOREIGN KEY (adminid)REFERENCES admin,
    FOREIGN KEY (instructorid)REFERENCES instructor
    on delete NO ACTION on update cascade
);
create table Assignment(
    cid int,
    number int not null,
    type varchar(10) not null,
    fullgrade int not null,
    weight decimal(4,1) not null,
    deadline datetime not null,
    content varchar (200) not null,
    PRIMARY KEY(cid,number,type),
    FOREIGN KEY (cid)REFERENCES course on delete cascade on update cascade
);
create table Feedback(
    cid int ,
    number int IDENTITY, 
    comment varchar(100) not null,
    numberOflikes int DEFAULT 0,
    sid int,
    PRIMARY KEY(cid,number),
     FOREIGN KEY (cid)REFERENCES course,
    FOREIGN KEY (sid)REFERENCES student
    on delete cascade on update cascade
);


create table Promocode(
    code VARCHAR(6),
    PRIMARY KEY(code),
    issuedate datetime not null,
    expirydate datetime not null,
    discountamount decimal(4,2) not null, 
    adminid int,
    FOREIGN KEY (adminid)REFERENCES admin
    on delete cascade on update cascade
);
create table StudentHasPromcode(
    sid int ,
    code varchar(6) ,
    PRIMARY KEY(code,sid),
    FOREIGN KEY (sid)REFERENCES student,
    FOREIGN KEY (code)REFERENCES promocode
    on delete cascade on update cascade
);

create table CreditCard(
Number varchar(15) not null,
cardHolderrName varchar(16) not null,
expiry_date DATETIME not null,
cvv VARCHAR(3) not null,
PRIMARY KEY(number)
);

create TABLE StudentAddCreditCard (
    sid int,
    creditcardnumber VARCHAR(15),
    primary key(sid,creditcardnumber),
    FOREIGN key (sid) REFERENCES Student,
    FOREIGN key (creditcardnumber) references creditcard On delete cascade On update cascade );



create table StudentTakeCourse(
    sid int,
    cid int,
    instid int,
    payedfor BIT,
    grade decimal(10,2),
    primary key(sid,cid,instid),
    FOREIGN key (sid) REFERENCES Student,
    FOREIGN key (cid) REFERENCES course,
    FOREIGN key (instid) REFERENCES instructor on delete CASCADE on update CASCADE

);
create table StudentTakeAssignment(
    sid int,
    cid int,
    assignmentnumber int,
    assignmenttype varchar(10),
    grade decimal(5,2),
    PRIMARY KEY(sid,cid,assignmentnumber,assignmenttype),
    FOREIGN KEY (sid)REFERENCES student,
    FOREIGN KEY (cid, assignmentnumber, assignmenttype)REFERENCES assignment on delete cascade on update CASCADE
);
create table StudentRateInstructor(
    sid int ,
    instid int ,
    rate int not null,
    PRIMARY KEY(sid,instid),
    FOREIGN KEY (sid)REFERENCES student,
    FOREIGN KEY (instid)REFERENCES instructor
    on delete cascade on update cascade

);
create table StudentCertifyCourse (
    sid int ,
    cid int ,
    issuedate DATETIME not null,
    PRIMARY KEY(sid,cid),
    FOREIGN KEY (sid)REFERENCES student,
    FOREIGN KEY (cid)REFERENCES course
    on delete cascade on update cascade
);

create table CoursePrerequisiteCourse(
    cid int ,
    prerequisiteid int,
    PRIMARY KEY (cid,prerequisiteid),
    FOREIGN KEY (prerequisiteid)REFERENCES course,
    FOREIGN KEY (cid)REFERENCES course
    on delete cascade on update cascade
);


create table InstructorTeachCourse(
    instid int ,
    cid int ,
    PRIMARY KEY(instid,cid),
    FOREIGN KEY (instid)REFERENCES instructor,
    FOREIGN KEY (cid)REFERENCES course
    on delete cascade on update cascade

);



